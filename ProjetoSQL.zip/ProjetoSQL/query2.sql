CREATE TABLE alunos (

    alunoid int AUTO_INCREMENT,

    nome varchar(255),

    numeroaluno int DEFAULT 0,

    email varchar(255),


    PRIMARY KEY(alunoid)

);
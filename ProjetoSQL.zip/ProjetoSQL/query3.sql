INSERT INTO alunos (nome, numeroaluno, email) VALUES ('João Carvalho', 1001, 'joao.carvalho@oficina.pt');

INSERT INTO alunos (nome, numeroaluno, email) VALUES ('Maria Silva', 1002, 'maria.silva@oficina.pt');

INSERT INTO alunos (nome, numeroaluno, email) VALUES ('Pedro Almeida', 1003, 'pedro.almeida@oficina.pt');


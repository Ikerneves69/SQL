/* Desativar as chaves estrangeiras temporariamente*/
SET FOREIGN_KEY_CHECKS = 0;

/* Leagues*/ 
INSERT INTO Leagues (id, name, description) VALUES
(1, 'Liga Portugal Betclic', 'Primeira divisão do futebol português'),
(2, 'Liga Portugal SABSEG', 'Segunda divisão do futebol português');

/* Players */
INSERT INTO Players (id, name, ranking, position) VALUES
(1, 'Pedro Gonçalves', 3, 'Médio Ofensivo'),
(2, 'Pepe', 5, 'Defesa Central'),
(3, 'Ricardo Horta', 4, 'Avançado'),
(4, 'Joel Tagueu', 12, 'Avançado');

/* Teams*/
INSERT INTO Teams (id, name, numPlayers, location, idLeague) VALUES
(1, 'Sporting CP', 25, 'Lisboa', 1),
(2, 'FC Porto', 24, 'Porto', 1),
(3, 'SC Braga', 23, 'Braga', 1),
(4, 'Marítimo', 22, 'Funchal', 2);

/* Teams_Players */
INSERT INTO Teams_Players (idTeam, idPlayer, since) VALUES
(1, 1, '2020-07-01'),
(2, 2, '2019-08-15'),
(3, 3, '2017-09-10'),
(4, 4, '2021-01-05');

/* Teams_Games*/
INSERT INTO Teams_Games (id, idTeam1, idTeam2, scoreTeam1, scoreTeam2, dateGame) VALUES
(1, 1, 2, 2, 1, '2024-03-10'),
(2, 2, 3, 1, 1, '2024-03-17'),
(3, 3, 4, 3, 0, '2024-04-01');

/* Players_Games */
INSERT INTO Players_Games (id, idPlayer1, idPlayer2, scorePlayer1, scorePlayer2, dateGame) VALUES
(1, 1, 2, 1, 0, '2024-03-10'),
(2, 3, 4, 2, 0, '2024-04-01');

/* Points */
INSERT INTO Points (id, description, points) VALUES
(1, 'Vitória', 3),
(2, 'Empate', 1),
(3, 'Derrota', 0);

/* Teams_Board */
INSERT INTO Teams_Board (id, idLeague, idTeam, position, totalPoints) VALUES
(1, 1, 1, 1, 7),
(2, 1, 2, 2, 4),
(3, 1, 3, 3, 3),
(4, 2, 4, 1, 6);

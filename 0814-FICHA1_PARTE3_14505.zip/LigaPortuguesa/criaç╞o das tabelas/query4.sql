-- Estrutura da tabela `leagues`
--

CREATE TABLE `leagues` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `leagues`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `players`
--

CREATE TABLE `players` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `ranking` int(11) NOT NULL,
  `position` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `players`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `players_games`
--

CREATE TABLE `players_games` (
  `id` int(11) NOT NULL,
  `idPlayer1` int(11) NOT NULL,
  `idPlayer2` int(11) NOT NULL,
  `scorePlayer1` int(11) NOT NULL,
  `scorePlayer2` int(11) NOT NULL,
  `dateGame` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `players_games`
--



-- --------------------------------------------------------

--
-- Estrutura da tabela `points`
--

CREATE TABLE `points` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `points` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `points`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `teams`
--

CREATE TABLE `teams` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `numPlayers` int(11) NOT NULL,
  `location` text NOT NULL,
  `idLeague` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `teams`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `teams_board`
--

CREATE TABLE `teams_board` (
  `id` int(11) NOT NULL,
  `idLeague` int(11) NOT NULL,
  `idTeam` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `totalPoints` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `teams_board`
--



-- --------------------------------------------------------

--
-- Estrutura da tabela `teams_games`
--

CREATE TABLE `teams_games` (
  `id` int(11) NOT NULL,
  `idTeam1` int(11) NOT NULL,
  `idTeam2` int(11) NOT NULL,
  `scoreTeam1` int(11) NOT NULL,
  `scoreTeam2` int(11) NOT NULL,
  `dateGame` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `teams_games`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `teams_players`
--

CREATE TABLE `teams_players` (
  `idTeam` int(11) NOT NULL,
  `idPlayer` int(11) NOT NULL,
  `since` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `teams_players`
--


--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `leagues`
--
ALTER TABLE `leagues`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `players_games`
--
ALTER TABLE `players_games`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idPlayer1` (`idPlayer1`,`idPlayer2`,`scorePlayer1`,`scorePlayer2`);

--
-- Índices para tabela `points`
--
ALTER TABLE `points`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `teams_board`
--
ALTER TABLE `teams_board`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idLeague` (`idLeague`,`idTeam`);

--
-- Índices para tabela `teams_games`
--
ALTER TABLE `teams_games`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idTeam1` (`idTeam1`,`idTeam2`,`scoreTeam1`,`scoreTeam2`);

--
-- Índices para tabela `teams_players`
--
ALTER TABLE `teams_players`
  ADD PRIMARY KEY (`idTeam`),
  ADD KEY `idPlayer` (`idPlayer`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `leagues`
--
ALTER TABLE `leagues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `players`
--
ALTER TABLE `players`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `players_games`
--
ALTER TABLE `players_games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `points`
--
ALTER TABLE `points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `teams_board`
--
ALTER TABLE `teams_board`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `teams_games`
--
ALTER TABLE `teams_games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `teams_players`
--
ALTER TABLE `teams_players`
  MODIFY `idTeam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

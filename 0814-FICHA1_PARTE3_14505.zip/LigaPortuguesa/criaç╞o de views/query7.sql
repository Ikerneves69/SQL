CREATE VIEW AS Teams_Leagues (
   SELECT * From teams as t1 LEFT JOIN `leagues` as lig ON t1.id = lig.id;
)

CREATE VIEW AS Teams_Games (
  SELECT * From teams as t1 LEFT JOIN `Teams_Games` as tg1 ON t1.id = tg1.id;
)

CREATE VIEW AS Teams_Players (
 SELECT * From teams as t1 LEFT JOIN `Players` as tg1 ON t1.id = tg1.id;
)
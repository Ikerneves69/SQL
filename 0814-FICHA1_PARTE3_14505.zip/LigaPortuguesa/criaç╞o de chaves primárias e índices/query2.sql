CREATE TABLE Leagues (

    id int AUTO_INCREMENT,

    name varchar(255),


    description varchar(255),


    PRIMARY KEY(id)

);
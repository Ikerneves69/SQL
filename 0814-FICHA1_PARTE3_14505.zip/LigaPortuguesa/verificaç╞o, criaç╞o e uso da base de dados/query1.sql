CREATE DATABASE LigaPortuguesa;

USE LigaPortuguesa;

